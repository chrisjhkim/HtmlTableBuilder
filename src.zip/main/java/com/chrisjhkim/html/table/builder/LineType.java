package com.chrisjhkim.html.table.builder;

public enum LineType {
	HEADER, BODY;


}
