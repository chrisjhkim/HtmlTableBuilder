package com.chrisjhkim.html.table.builder;

import java.util.ArrayList;
import java.util.List;

public class HtmlTableBuilder {
	private boolean includeLineBreak = true;
	private List<TableLine> tableLines = new ArrayList<>();
	private StringBuilder sb = new StringBuilder();

	public void addLine(TableLine line){
		tableLines.add(line);

	}
	public String build() {
		appendLine("<table>");




		for (TableLine tableLine : tableLines) {
			appendTableLine(tableLine);
		}

		appendLine("</table>");

		return sb.toString();
	}

	private void appendTableLine(TableLine tableLine) {
		appendLine("<tr>");

		for (TableColumn tableColumn : tableLine.getTableColumns()) {
			if ( tableLine.lineType == LineType.HEADER ) {
				appendLine("<th>",tableColumn.getValue(),"</th>");

			}else if ( tableLine.lineType == LineType.BODY ) {
				appendLine("<td>", tableColumn.getValue(), "</td>");
			}
		}
		appendLine("</tr>");
	}

	private StringBuilder appendLine(String ... str) {
		for (String s : str) {
			sb.append(s);
		}
		if ( includeLineBreak) {
			sb.append("\r\n");
		}
		return sb;
	}

	public HtmlTableHeaderBuilder startHeaderTr() {
		return new HtmlTableHeaderBuilder(this);
	}
	public HtmlTableBodyBuilder startBodyTr() {
		return new HtmlTableBodyBuilder(this);
	}


	public static class HtmlTableHeaderBuilder extends HtmlTableLineBuilder{
		public HtmlTableHeaderBuilder(HtmlTableBuilder htmlTableBuilder) {
			super(htmlTableBuilder, LineType.HEADER);
		}
		public HtmlTableHeaderBuilder th(String columnValue){
			super.addColumn(columnValue);
			return this;
		}
		public HtmlTableBuilder finishHeaderTr(){
			return super.endLine();
		}
	}
	public static class HtmlTableBodyBuilder extends HtmlTableLineBuilder{
		public HtmlTableBodyBuilder(HtmlTableBuilder htmlTableBuilder) {
			super(htmlTableBuilder, LineType.BODY);
		}
		public HtmlTableBodyBuilder td(String columnValue){
			super.addColumn(columnValue);
			return this;
		}
		public HtmlTableBuilder finishBodyTr(){
			return super.endLine();
		}
	}

	public static class HtmlTableLineBuilder{
		private HtmlTableBuilder parent;
		private TableLine line;
		public HtmlTableLineBuilder(HtmlTableBuilder htmlTableBuilder, LineType lineType) {
			this.parent = htmlTableBuilder;

			this.line = new TableLine(lineType);
			this.parent.addLine(this.line);
		}

		public HtmlTableLineBuilder addColumn(String columnValue) {
			this.line.addColumn(columnValue);
			return this;
		}

		public HtmlTableBuilder endLine() {
			return this.parent;
		}
	}

	public static class TableLine {
		private final LineType lineType;
		List<TableColumn> tableColumns = new ArrayList<>();

		public TableLine(LineType lineType) {
			this.lineType = lineType;
		}

		public List<TableColumn> getTableColumns() {
			return tableColumns;
		}

		public void addColumn(String columnValue) {
			TableColumn tableColumn = new TableColumn(columnValue);
			this.tableColumns.add(tableColumn);
		}
	}
	private static class TableColumn{
		private final String value;

		public TableColumn(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}
}
