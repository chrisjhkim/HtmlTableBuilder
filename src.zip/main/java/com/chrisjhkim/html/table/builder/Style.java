package com.chrisjhkim.html.table.builder;

public class Style {
}
