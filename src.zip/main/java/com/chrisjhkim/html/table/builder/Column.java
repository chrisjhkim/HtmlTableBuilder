package com.chrisjhkim.html.table.builder;

public class Column {
}
