package com.chrisjhkim.html.table.builder;

public class Line {
}
